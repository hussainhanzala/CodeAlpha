# CodeAlpha_FAQChatbot

**CodeAlpha AI Internship — Task 2: Chatbot for FAQs**

A chatbot that answers questions about the CodeAlpha internship by matching the user's question to the most similar FAQ.

## How It Works
1. **Collect FAQs** – 18 question/answer pairs stored in `faqs.json` (easy to edit/extend).
2. **Preprocess** with NLTK – lowercase, remove punctuation, tokenize, remove stopwords, lemmatize.
3. **Vectorize** FAQ questions with TF-IDF (unigrams + bigrams).
4. **Match** the user's question using **cosine similarity**.
5. **Respond** with the best answer; if similarity is below a threshold, a polite fallback is shown.

## Files
| File | Purpose |
|------|---------|
| `chatbot.py` | NLP pipeline + `FAQChatbot` class (also runs as a console chatbot) |
| `app.py` | Streamlit chat UI |
| `faqs.json` | FAQ dataset |

## Run
```bash
pip install -r requirements.txt

# Console version
python chatbot.py

# Chat UI
streamlit run app.py
```

## Example
```
You: how do i get my certificate?
Bot: Yes. Interns who complete the required tasks receive a QR verified completion certificate with a unique ID.
```

## Tech Stack
Python, NLTK, scikit-learn, Streamlit

## Author
Made as part of the CodeAlpha Artificial Intelligence Internship.
