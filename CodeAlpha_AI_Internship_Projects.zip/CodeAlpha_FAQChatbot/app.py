"""
Streamlit chat UI for the FAQ chatbot.
Run:  streamlit run app.py
"""
import streamlit as st

from chatbot import FAQChatbot

st.set_page_config(page_title="CodeAlpha FAQ Chatbot", page_icon="🤖")


@st.cache_resource
def load_bot():
    return FAQChatbot()


bot = load_bot()

st.title("🤖 CodeAlpha FAQ Chatbot")
st.caption("CodeAlpha AI Internship · Task 2 — ask me anything about the internship")

with st.sidebar:
    st.header("Sample FAQs")
    for q in bot.questions[:8]:
        if st.button(q, use_container_width=True):
            st.session_state.pending = q
    st.divider()
    if st.button("Clear chat"):
        st.session_state.messages = []
        st.rerun()

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hi! I'm the CodeAlpha FAQ bot. How can I help you today?"}
    ]

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

user_input = st.chat_input("Type your question...") or st.session_state.pop("pending", None)

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    answer, matched, score = bot.get_response(user_input)
    reply = answer
    if matched:
        reply += f"\n\n*Matched FAQ: {matched} (similarity {score:.0%})*"
    st.session_state.messages.append({"role": "assistant", "content": reply})
    with st.chat_message("assistant"):
        st.markdown(reply)
