"""
CodeAlpha AI Internship - Task 2: Chatbot for FAQs
--------------------------------------------------
Pipeline:
  1. Load FAQs (question/answer pairs) from faqs.json
  2. Preprocess text with NLTK (lowercase, remove punctuation, tokenize,
     remove stopwords, lemmatize)
  3. Convert FAQ questions to TF-IDF vectors
  4. Match a user question to the most similar FAQ using cosine similarity
  5. Return the best answer (or a fallback if similarity is too low)
"""
import json
import os
import re

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

HERE = os.path.dirname(os.path.abspath(__file__))


def _download_nltk_data():
    for pkg, path in [
        ("punkt", "tokenizers/punkt"),
        ("punkt_tab", "tokenizers/punkt_tab"),
        ("stopwords", "corpora/stopwords"),
        ("wordnet", "corpora/wordnet"),
    ]:
        try:
            nltk.data.find(path)
        except LookupError:
            try:
                nltk.download(pkg, quiet=True)
            except Exception:
                pass


_download_nltk_data()
_lemmatizer = WordNetLemmatizer()
# Built-in fallback so the bot still works if NLTK data cannot be downloaded
_FALLBACK_STOP = set(
    "a an the is are was were be been am do does did i me my we our you your it its he she they them "
    "this that these those of to in on at for from by with about as and or but if so than then too very "
    "can could will would should may might must have has had how what when where which who whom why "
    "get got there here up out any some also just".split()
)
try:
    _stop = set(stopwords.words("english")) - {"not", "no"}
except LookupError:
    _stop = _FALLBACK_STOP


def preprocess(text: str) -> str:
    """Lowercase -> strip punctuation -> tokenize -> remove stopwords -> lemmatize."""
    text = re.sub(r"[^a-z0-9\s]", " ", text.lower())
    try:
        tokens = word_tokenize(text)
    except LookupError:
        tokens = text.split()
    tokens = [t for t in tokens if t not in _stop]
    try:
        tokens = [_lemmatizer.lemmatize(t) for t in tokens]
    except LookupError:
        # crude fallback when WordNet is unavailable
        tokens = [re.sub(r"(ing|ed|es|s|e|d)$", "", t) if len(t) > 3 else t for t in tokens]
    return " ".join(tokens)


class FAQChatbot:
    def __init__(self, faq_path=None, threshold=0.2):
        faq_path = faq_path or os.path.join(HERE, "faqs.json")
        with open(faq_path, encoding="utf-8") as f:
            self.faqs = json.load(f)
        self.threshold = threshold
        self.questions = [item["question"] for item in self.faqs]
        # Index the question (weighted x2) plus its answer so keywords in either help matching
        # Optional "variants" = alternate phrasings of the same question
        docs = [
            preprocess(" ".join([i["question"]] * 2 + i.get("variants", []) + [i["answer"]]))
            for i in self.faqs
        ]
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2))
        self.matrix = self.vectorizer.fit_transform(docs)

    def get_response(self, user_input: str):
        """Returns (answer, matched_question, score)."""
        cleaned = preprocess(user_input)
        if not cleaned.strip():
            return "Please type a question so I can help you.", None, 0.0
        vec = self.vectorizer.transform([cleaned])
        scores = cosine_similarity(vec, self.matrix)[0]
        best = int(scores.argmax())
        score = float(scores[best])
        if score < self.threshold:
            return (
                "Sorry, I couldn't find an answer to that. Try rephrasing, or contact "
                "services@codealpha.tech.",
                None,
                score,
            )
        return self.faqs[best]["answer"], self.questions[best], score


def main():
    bot = FAQChatbot()
    print("CodeAlpha FAQ Bot - type 'quit' to exit.")
    while True:
        q = input("You: ").strip()
        if q.lower() in {"quit", "exit", "bye"}:
            print("Bot: Goodbye!")
            break
        answer, matched, score = bot.get_response(q)
        print(f"Bot: {answer}")
        if matched:
            print(f"     (matched: '{matched}', similarity {score:.2f})")


if __name__ == "__main__":
    main()
