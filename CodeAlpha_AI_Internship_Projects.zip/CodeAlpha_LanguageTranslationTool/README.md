# CodeAlpha_LanguageTranslationTool

**CodeAlpha AI Internship — Task 1: Language Translation Tool**

A simple web app where you type text, pick the source and target languages, and get the translation instantly.

## Features
- Enter text and choose source & target language (100+ languages)
- **Auto Detect** for the source language
- **Swap** button to flip source and target
- Translation powered by Google Translate (through the `deep-translator` library, no API key needed)
- **Copy** button to copy the translated text
- **Text-to-Speech** (gTTS) to listen to the translation

## Tech Stack
Python, Streamlit, deep-translator, gTTS

## How to Run
```bash
pip install -r requirements.txt
streamlit run app.py
```
Then open http://localhost:8501 in your browser.

## How It Works
1. User enters text and selects languages in the Streamlit UI.
2. The text is sent to the Google Translate API through `deep-translator`.
3. The translated response is displayed on screen.
4. Optionally copy it or play it as audio with gTTS.

## Author
Made as part of the CodeAlpha Artificial Intelligence Internship.
