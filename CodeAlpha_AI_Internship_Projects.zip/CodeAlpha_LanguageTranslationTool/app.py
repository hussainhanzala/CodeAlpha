"""
CodeAlpha AI Internship - Task 1: Language Translation Tool
-----------------------------------------------------------
Streamlit UI + Google Translate (via deep-translator, no API key needed)
Features: source/target language selection, auto-detect, swap languages,
copy button and text-to-speech (gTTS).

Run:  streamlit run app.py
"""
import io
import json

import streamlit as st
import streamlit.components.v1 as components
from deep_translator import GoogleTranslator
from gtts import gTTS

st.set_page_config(page_title="Language Translation Tool", page_icon="🌐", layout="centered")

# {name: code} supported by Google Translate
LANGUAGES = GoogleTranslator().get_supported_languages(as_dict=True)
NAMES = sorted(n.title() for n in LANGUAGES.keys())
SOURCE_NAMES = ["Auto Detect"] + NAMES

# gTTS supports a subset of languages; we check at runtime
try:
    from gtts.lang import tts_langs

    TTS_LANGS = tts_langs()
except Exception:  # pragma: no cover
    TTS_LANGS = {}


def code_of(name: str) -> str:
    return "auto" if name == "Auto Detect" else LANGUAGES[name.lower()]


# ---------- session state (needed so the swap button works) ----------
st.session_state.setdefault("src", "English")
st.session_state.setdefault("tgt", "Urdu")


def swap_languages():
    if st.session_state.src == "Auto Detect":
        st.session_state.warn = "Cannot swap when source is 'Auto Detect'."
        return
    st.session_state.src, st.session_state.tgt = st.session_state.tgt, st.session_state.src


# ---------------------------- UI ----------------------------
st.title("🌐 Language Translation Tool")
st.caption("CodeAlpha AI Internship · Task 1")

c1, c2, c3 = st.columns([5, 1, 5])
c1.selectbox("From", SOURCE_NAMES, key="src")
c2.write("")
c2.write("")
c2.button("⇄", on_click=swap_languages, help="Swap languages")
c3.selectbox("To", NAMES, key="tgt")

if st.session_state.pop("warn", None):
    st.warning("Cannot swap when source is 'Auto Detect'.")

text = st.text_area("Enter text", height=160, max_chars=5000, placeholder="Type or paste text here...")

if st.button("Translate", type="primary", use_container_width=True):
    if not text.strip():
        st.warning("Please enter some text to translate.")
    else:
        try:
            with st.spinner("Translating..."):
                translated = GoogleTranslator(
                    source=code_of(st.session_state.src),
                    target=code_of(st.session_state.tgt),
                ).translate(text)
            st.session_state.result = translated
            st.session_state.result_lang = code_of(st.session_state.tgt)
        except Exception as e:
            st.error(f"Translation failed: {e}")

result = st.session_state.get("result")
if result:
    st.subheader("Translation")
    st.text_area("Translated text", value=result, height=160, key="out_box")

    col_a, col_b = st.columns(2)
    with col_a:
        # Copy button (browser clipboard via a tiny HTML component)
        components.html(
            f"""
            <button id="cp" style="width:100%;padding:9px;border:1px solid #ccc;border-radius:8px;
                background:#fff;cursor:pointer;font-size:15px;">📋 Copy</button>
            <script>
            const t = {json.dumps(result)};
            document.getElementById('cp').onclick = async () => {{
                try {{ await navigator.clipboard.writeText(t); }}
                catch(e) {{
                    const a = document.createElement('textarea'); a.value = t;
                    document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove();
                }}
                document.getElementById('cp').innerText = '✅ Copied!';
            }};
            </script>
            """,
            height=50,
        )
    with col_b:
        if st.button("🔊 Listen", use_container_width=True):
            lang = st.session_state.result_lang
            if lang not in TTS_LANGS:
                st.info("Text-to-speech is not available for this language.")
            else:
                try:
                    buf = io.BytesIO()
                    gTTS(text=result, lang=lang).write_to_fp(buf)
                    st.audio(buf.getvalue(), format="audio/mp3")
                except Exception as e:
                    st.error(f"Text-to-speech failed: {e}")
