# CodeAlpha_ObjectDetectionTracking

**CodeAlpha AI Internship — Task 4: Object Detection and Tracking**

Real-time object detection and tracking from a webcam or video file. Each object gets a bounding box, a class label and a unique tracking ID.

## Pipeline
1. **Video input** – webcam or video file using OpenCV.
2. **Detection** – pre-trained **YOLOv8** (COCO, 80 classes).
3. **Tracking** – **DeepSORT** (default) or **ByteTrack** (SORT-family) to keep IDs consistent across frames.
4. **Output** – live window with boxes, labels, tracking IDs and FPS; optionally saved to a video file.

## Install & Run
```bash
pip install -r requirements.txt

python detect_track.py                          # webcam + DeepSORT
python detect_track.py --source video.mp4       # video file
python detect_track.py --tracker bytetrack      # use ByteTrack instead
python detect_track.py --classes person car     # track only some classes
python detect_track.py --source video.mp4 --save output.mp4 --no-show
```
Press **q** in the window to quit. YOLO weights (`yolov8n.pt`) download automatically on first run.

## Options
| Flag | Meaning |
|------|---------|
| `--source` | `0` for webcam or a video path |
| `--model` | YOLO weights (`yolov8n.pt`, `yolov8s.pt`, ...) |
| `--tracker` | `deepsort` or `bytetrack` |
| `--conf` | detection confidence threshold (default 0.4) |
| `--classes` | filter by class names |
| `--save` | save annotated video |
| `--no-show` | run without a display window |

## Tech Stack
Python, OpenCV, Ultralytics YOLOv8, deep-sort-realtime

## Author
Made as part of the CodeAlpha Artificial Intelligence Internship.
