"""
CodeAlpha AI Internship - Task 4: Object Detection and Tracking
---------------------------------------------------------------
- Video input: webcam or video file (OpenCV)
- Detection : pre-trained YOLOv8 (Ultralytics, COCO classes)
- Tracking  : DeepSORT (deep-sort-realtime), or ByteTrack built into Ultralytics
- Output    : real-time window with bounding boxes, class labels and tracking IDs

Usage:
    python detect_track.py                       # webcam, DeepSORT
    python detect_track.py --source video.mp4    # video file
    python detect_track.py --source 0 --tracker bytetrack
    python detect_track.py --source video.mp4 --save output.mp4 --no-show
    python detect_track.py --classes person car  # only track these classes
"""
import argparse
import time

import cv2
from ultralytics import YOLO


def parse_args():
    p = argparse.ArgumentParser(description="YOLO object detection + tracking")
    p.add_argument("--source", default="0", help="0 for webcam, or path to a video file")
    p.add_argument("--model", default="yolov8n.pt", help="YOLO weights (auto-downloaded)")
    p.add_argument("--tracker", choices=["deepsort", "bytetrack"], default="deepsort")
    p.add_argument("--conf", type=float, default=0.4, help="confidence threshold")
    p.add_argument("--classes", nargs="*", default=None, help="class names to keep, e.g. person car")
    p.add_argument("--save", default=None, help="path to save annotated video (e.g. out.mp4)")
    p.add_argument("--no-show", action="store_true", help="do not open a display window")
    return p.parse_args()


def color_for_id(track_id: int):
    """Stable, distinct colour per tracking ID."""
    import colorsys

    h = (track_id * 0.618033988749895) % 1.0
    r, g, b = colorsys.hsv_to_rgb(h, 0.85, 0.95)
    return int(b * 255), int(g * 255), int(r * 255)


def draw_box(frame, x1, y1, x2, y2, label, color):
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
    (tw, th), bl = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)
    cv2.rectangle(frame, (x1, y1 - th - bl - 4), (x1 + tw + 4, y1), color, -1)
    cv2.putText(frame, label, (x1 + 2, y1 - bl - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)


def main():
    args = parse_args()
    model = YOLO(args.model)
    names = model.names  # {id: name}

    wanted_ids = None
    if args.classes:
        lookup = {v.lower(): k for k, v in names.items()}
        wanted_ids = [lookup[c.lower()] for c in args.classes if c.lower() in lookup]

    source = int(args.source) if args.source.isdigit() else args.source
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise SystemExit(f"Could not open video source: {args.source}")

    fps_in = cap.get(cv2.CAP_PROP_FPS) or 30
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    writer = None
    if args.save:
        writer = cv2.VideoWriter(args.save, cv2.VideoWriter_fourcc(*"mp4v"), fps_in, (w, h))

    deepsort = None
    if args.tracker == "deepsort":
        from deep_sort_realtime.deepsort_tracker import DeepSort

        deepsort = DeepSort(max_age=30, n_init=3)

    prev = time.time()
    print("Running... press 'q' in the window to quit.")
    while True:
        ok, frame = cap.read()
        if not ok:
            break

        if args.tracker == "bytetrack":
            # Detection + tracking in one call (ByteTrack is a SORT-family tracker)
            res = model.track(frame, persist=True, tracker="bytetrack.yaml",
                              conf=args.conf, classes=wanted_ids, verbose=False)[0]
            if res.boxes is not None and res.boxes.id is not None:
                for box, tid, cls in zip(res.boxes.xyxy.int().tolist(),
                                         res.boxes.id.int().tolist(),
                                         res.boxes.cls.int().tolist()):
                    x1, y1, x2, y2 = box
                    draw_box(frame, x1, y1, x2, y2, f"ID {tid} {names[cls]}", color_for_id(tid))
        else:
            # 1) Detect with YOLO
            res = model(frame, conf=args.conf, classes=wanted_ids, verbose=False)[0]
            detections = []
            for (x1, y1, x2, y2), conf, cls in zip(res.boxes.xyxy.tolist(),
                                                    res.boxes.conf.tolist(),
                                                    res.boxes.cls.int().tolist()):
                # DeepSORT expects ([left, top, w, h], confidence, class)
                detections.append(([x1, y1, x2 - x1, y2 - y1], conf, cls))
            # 2) Track with DeepSORT
            tracks = deepsort.update_tracks(detections, frame=frame)
            for t in tracks:
                if not t.is_confirmed() or t.time_since_update > 0:
                    continue
                x1, y1, x2, y2 = map(int, t.to_ltrb())
                cls = t.get_det_class()
                label = f"ID {t.track_id} {names.get(cls, cls)}"
                draw_box(frame, x1, y1, x2, y2, label, color_for_id(int(t.track_id)))

        now = time.time()
        fps = 1.0 / max(now - prev, 1e-6)
        prev = now
        cv2.putText(frame, f"FPS: {fps:.1f}  Tracker: {args.tracker}", (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        if writer:
            writer.write(frame)
        if not args.no_show:
            cv2.imshow("CodeAlpha - Object Detection & Tracking", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    cap.release()
    if writer:
        writer.release()
        print(f"Saved output to {args.save}")
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
