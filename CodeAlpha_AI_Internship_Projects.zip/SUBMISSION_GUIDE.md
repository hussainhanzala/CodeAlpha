# CodeAlpha AI Internship - Submission Guide (aaj hi karo!)

## 1. Pehle apni machine par run karke dekh lo (5 min)
```bash
# Task 1
cd CodeAlpha_LanguageTranslationTool && pip install -r requirements.txt && streamlit run app.py

# Task 2
cd CodeAlpha_FAQChatbot && pip install -r requirements.txt && streamlit run app.py

# Task 4
cd CodeAlpha_ObjectDetectionTracking && pip install -r requirements.txt && python detect_track.py
```
(Task 4 pehli baar YOLO weights download karega, internet chahiye. Webcam na ho to `--source video.mp4` use karo.)

## 2. GitHub par upload (har project ki alag repo, naam EXACTLY ye ho)
- `CodeAlpha_LanguageTranslationTool`
- `CodeAlpha_FAQChatbot`
- `CodeAlpha_ObjectDetectionTracking`

```bash
cd CodeAlpha_FAQChatbot
git init
git add .
git commit -m "CodeAlpha internship task"
git branch -M main
git remote add origin https://github.com/<TUMHARA_USERNAME>/CodeAlpha_FAQChatbot.git
git push -u origin main
```
(GitHub par pehle empty repo banao, phir upar wali commands. Baaki do ke liye bhi same.)

## 3. LinkedIn video (har project ka 1-2 min ka screen recording)
Script:
> "Hi, I'm <Name>. As part of my @CodeAlpha AI internship, I built <Project>.
> It works like this: <1-2 lines>. Let me show a quick demo... (demo dikhao)
> The full source code is on GitHub, link in the post. Thank you CodeAlpha!"

## 4. LinkedIn post template
```
Excited to share that I completed my Artificial Intelligence internship at @CodeAlpha! 🚀

Projects I built:
🌐 Language Translation Tool - <GitHub link>
🤖 FAQ Chatbot (NLP) - <GitHub link>
🎯 Object Detection & Tracking (YOLOv8 + DeepSORT) - <GitHub link>

Thank you @CodeAlpha for the great learning experience!
#CodeAlpha #AI #MachineLearning #Internship #Python
```

## 5. Submission form
WhatsApp group mein jo form share hua hai, usme GitHub links + LinkedIn post link daal ke submit karo.
